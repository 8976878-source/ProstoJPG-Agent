# ПростоJPG Free от ПростоСеллера

Создавайте карточки товаров для Wildberries и Ozon по загруженным фото.
Промпты уже встроены. **Без входа в ChatGPT, без API-ключей и без подписок** —
генерация идёт встроенным инструментом генерации изображений того агента, в
котором вы работаете.

> ⭐ Если плагин пригодился — поставьте звезду на GitHub. Это одна кнопка, а для
> автора — основная мотивация развивать проект дальше.

## Чем отличается от ProstoJPG 2.0

| | ProstoJPG 2.0 | **ProstoJPG Free** |
|---|---|---|
| Генерация | Codex + вход через ChatGPT | инструмент генерации самого агента |
| Логин / ключ / подписка | нужен аккаунт ChatGPT | **не нужны** |
| Где работает | Codex / Claude Code | Arena, Codex, Claude Code, Cursor, любой агент с генерацией картинок |
| Браузерное расширение | нужно для скачивания фото | **не нужно** — фото прикладываются в чат |
| Обработка файлов | локальные скрипты | локальные скрипты (те же правила) |

Качество и «узнаваемость товара» зависят от генератора вашего клиента: чем
сильнее модель изображений, тем ближе результат к оригинальной карточке.

## Быстрый старт

1. Приложите в чат исходные фото карточки (можно ZIP, папку или файл).
2. Выберите режим и напишите команду.

| Режим | Команда в Arena | В Codex | В Claude Code | Что делает |
|---|---|---|---|---|
| 1 | «создай похожую карточку» | `$prostojpg-free-1` | `/prostojpg-free:prostojpg-free-1` | похожая карточка, товар узнаваем |
| 2 | «замени товар на моём фото и смени лицо» | `$prostojpg-free-2` | `/prostojpg-free:prostojpg-free-2` | исходник + ваш товар + новое лицо |
| 3 | «замени товар, лицо не меняй» | `$prostojpg-free-3` | `/prostojpg-free:prostojpg-free-3` | исходник + ваш товар, лицо прежнее |

Артикул и собственный промпт не нужны.

Команды вводить не обязательно. Сразу после установки плагин показывает окно с
готовыми ответами-подсказками — три кнопки режимов. После любого прикреплённого
фото агент спрашивает, что делаем: режим 1 — карточка готова сразу; режим 2 или 3 —
агент попросит ещё одно фото, сам товар. После каждой готовой карточки меню
появляется снова.

## Отзыв

Если вы пользуетесь расширением [ПростоJPG в Chrome Web Store](https://chromewebstore.google.com/detail/%D0%BF%D1%80%D0%BE%D1%81%D1%82%D0%BEjpg/djjocjgglhbkcfclclilmamlcoggoole) —
поставьте оценку и короткий отзыв, это помогает проекту. Плагин напоминает об этом
не чаще раза в день и перестаёт после того, как вы оставите отзыв.

## Новый чат в Arena

Arena не хранит плагин между чатами: он живёт в воркспейсе беседы, а не в реестре.
Если новый чат начался с пустым `/home/user` — поставьте плагин одной командой:

```bash
git clone --depth 1 https://github.com/8976878-source/ProstoJPG-Free.git /home/user/ProstoJPG-Free
```

или просто напишите агенту: «Установи https://github.com/8976878-source/ProstoJPG-Free».
Если папка уже есть (`ls /home/user/ProstoJPG-Free`) — достаточно `bash update.sh`.
Проверить версию: `python3 plugins/prostojpg-free/scripts/cards.py version`.

## Обновление

Напишите в чате **«обнови»** — плагин скачает свежую версию с GitHub и покажет,
что изменилось. Вручную то же самое делает `bash update.sh`, а версию показывает
`python3 plugins/prostojpg-free/scripts/cards.py version`.

## Правила результата

- Пропорции каждого фото — как у оригинала.
- Короткая сторона не меньше 1200 px; недостающее добивается белыми полями без
  обрезки товара.
- Готовые фото — отдельными файлами, без ZIP.
- Видео не генерируются.
- Исходники и результаты остаются у вас; плагин не ходит ни в какие платные API.

## Установка

Полная инструкция — [INSTALL.md](INSTALL.md). Здесь, в Arena, плагин уже стоит:
`/home/user/ProstoJPG-Free`. Для Codex и Claude Code:

```text
codex plugin marketplace add 8976878-source/ProstoJPG-Free
codex plugin add prostojpg-free@prostojpg-free-marketplace
```

```text
claude plugin marketplace add 8976878-source/ProstoJPG-Free
claude plugin install prostojpg-free@prostojpg-free-marketplace
```

Зависимость для сборки фото: Python 3.9+ и `pip install "Pillow>=10.4"`.

## Структура

```
.agents/plugins/marketplace.json        marketplace для Codex
.claude-plugin/marketplace.json          marketplace для Claude Code
plugins/prostojpg-free/
  .claude-plugin/plugin.json
  skills/prostojpg-free-1..3/SKILL.md    навыки трёх режимов
  scripts/cards.py                       prepare / export / info (без сети)
  scripts/requirements.txt               Pillow
references/generation.md                 правила обработки и диагностика
downloads/*.zip                          готовые архивы плагина
```

Версия 1.0.9. Лицензия: MIT (см. LICENSE).
